module.exports = {
  id: 179335387,
  node_id: "MDEwOlJlcG9zaXRvcnkxNzkzMzUzODc=",
  name: "team1Repository1Store",
  full_name: "ejswenson15/team1Repository1Store",
  private: false,
  owner: {
    login: "ejswenson15",
    id: 29992901,
    node_id: "MDQ6VXNlcjI5OTkyOTAx",
    avatar_url: "https://avatars1.githubusercontent.com/u/29992901?v=4",
    gravatar_id: "",
    url: "https://api.github.com/users/ejswenson15",
    html_url: "https://github.com/ejswenson15",
    followers_url: "https://api.github.com/users/ejswenson15/followers",
    following_url:
      "https://api.github.com/users/ejswenson15/following{/other_user}",
    gists_url: "https://api.github.com/users/ejswenson15/gists{/gist_id}",
    starred_url:
      "https://api.github.com/users/ejswenson15/starred{/owner}{/repo}",
    subscriptions_url: "https://api.github.com/users/ejswenson15/subscriptions",
    organizations_url: "https://api.github.com/users/ejswenson15/orgs",
    repos_url: "https://api.github.com/users/ejswenson15/repos",
    events_url: "https://api.github.com/users/ejswenson15/events{/privacy}",
    received_events_url:
      "https://api.github.com/users/ejswenson15/received_events",
    type: "User",
    site_admin: false
  },
  html_url: "https://github.com/ejswenson15/team1Repository1Store",
  description: "Feature which implements the store feature of the website.",
  fork: false,
  url: "https://api.github.com/repos/ejswenson15/team1Repository1Store",
  forks_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/forks",
  keys_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/keys{/key_id}",
  collaborators_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/collaborators{/collaborator}",
  teams_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/teams",
  hooks_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/hooks",
  issue_events_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/issues/events{/number}",
  events_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/events",
  assignees_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/assignees{/user}",
  branches_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/branches{/branch}",
  tags_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/tags",
  blobs_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/git/blobs{/sha}",
  git_tags_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/git/tags{/sha}",
  git_refs_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/git/refs{/sha}",
  trees_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/git/trees{/sha}",
  statuses_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/statuses/{sha}",
  languages_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/languages",
  stargazers_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/stargazers",
  contributors_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/contributors",
  subscribers_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/subscribers",
  subscription_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/subscription",
  commits_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/commits{/sha}",
  git_commits_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/git/commits{/sha}",
  comments_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/comments{/number}",
  issue_comment_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/issues/comments{/number}",
  contents_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/contents/{+path}",
  compare_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/compare/{base}...{head}",
  merges_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/merges",
  archive_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/{archive_format}{/ref}",
  downloads_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/downloads",
  issues_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/issues{/number}",
  pulls_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/pulls{/number}",
  milestones_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/milestones{/number}",
  notifications_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/notifications{?since,all,participating}",
  labels_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/labels{/name}",
  releases_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/releases{/id}",
  deployments_url:
    "https://api.github.com/repos/ejswenson15/team1Repository1Store/deployments",
  created_at: "2019-04-03T17:11:23Z",
  updated_at: "2019-04-03T21:35:39Z",
  pushed_at: "2019-04-03T21:35:38Z",
  git_url: "git://github.com/ejswenson15/team1Repository1Store.git",
  ssh_url: "git@github.com:ejswenson15/team1Repository1Store.git",
  clone_url: "https://github.com/ejswenson15/team1Repository1Store.git",
  svn_url: "https://github.com/ejswenson15/team1Repository1Store",
  homepage: null,
  size: 0,
  stargazers_count: 0,
  watchers_count: 0,
  language: "JavaScript",
  has_issues: true,
  has_projects: true,
  has_downloads: true,
  has_wiki: true,
  has_pages: false,
  forks_count: 0,
  mirror_url: null,
  archived: false,
  disabled: false,
  open_issues_count: 8,
  license: null,
  forks: 0,
  open_issues: 8,
  watchers: 0,
  default_branch: "master"
};
