const firebase = require("firebase");

var developmentConfigurationForFirebase = {
  apiKey: "AIzaSyC073gs8IJ0xs_1b6MVGS01oVSI6C0OAFE",
  authDomain: "repository-and-issue-count.firebaseapp.com",
  databaseURL: "https://repository-and-issue-count.firebaseio.com",
  projectId: "repository-and-issue-count",
  storageBucket: "repository-and-issue-count.appspot.com",
  messagingSenderId: "676726679095"
};

let developmentReference;
if (firebase.apps.length == 0) {
  developmentReference = firebase.initializeApp(
    developmentConfigurationForFirebase
  );
}

exports.handler = async (event, context, callback) => {
  console.log(event.Records[0].Sns);
  let repositoryAndIssueCount = JSON.parse(event.Records[0].Sns.Message);

  for (let repositoryName in repositoryAndIssueCount) {
    await developmentReference
      .database()
      .ref(`/${repositoryName}`)
      .once("value")
      .then(async data => {
        if (
          parseInt(data.val()) <
          parseInt(repositoryAndIssueCount[repositoryName])
        ) {
          await databasePromise(
            data.val(),
            repositoryAndIssueCount,
            repositoryName
          );
        }
        await developmentReference
          .database()
          .ref("/")
          .update({
            [repositoryName]: repositoryAndIssueCount[repositoryName]
          });
      });
  }
};

const databasePromise = (
  previousIssueCount,
  repositoryAndIssueCount,
  repositoryName
) => {
  return new Promise((resolve, reject) => {
    developmentReference
      .database()
      .ref(`/totalCounts/${repositoryName}`)
      .once("value")
      .then(data => {
        let previousTotal = data.val();

        let newTotal =
          previousTotal +
          (parseInt(repositoryAndIssueCount[repositoryName]) -
            previousIssueCount);

        developmentReference
          .database()
          .ref(`/totalCounts/`)
          .update({ [repositoryName]: newTotal })
          .then(() => {
            developmentReference
              .database()
              .ref(`/`)
              .update({
                [repositoryName]: repositoryAndIssueCount[repositoryName]
              })
              .then(() => {
                resolve();
              });
          });
      });
  });
};
