module.exports = JSON.stringify({
  Records: [
    {
      EventSource: "aws:sns",
      EventVersion: "1.0",
      EventSubscriptionArn:
        "arn:aws:sns:us-east-1:193442566719:publishIssueCountOfAllRepositories:3ddbf538-1ac4-4d10-969d-789324f03ff9",
      Sns: [Object]
    }
  ]
});
