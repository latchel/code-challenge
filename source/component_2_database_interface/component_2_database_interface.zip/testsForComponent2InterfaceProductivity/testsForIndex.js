const { handler } = require("../index.js");

const sampleEvent = require("./samplePublishedMessageFromSNS");

const testThatComponentCorrectlyCalculatesAndStoresIssues = () => {
  handler(sampleEvent);
};
