const httpsReference = require("https");

const AWS = require("aws-sdk");

exports.handler = async () => {
  await storeAllNewFeaturesWithTimeStamps();
};

const storeAllNewFeaturesWithTimeStamps = repositoryName => {
  return new Promise((resolve, reject) => {
    let bmpString = "";

    httpsReference.get(
      {
        hostname: "api.github.com",
        path: "/users/ejswenson15/repos",
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1521.3 Safari/537.36"
        }
      },
      res => {
        res.on("data", function(data) {
          bmpString += data.toString("utf8");
          console.log(bmpString);
        });
        res.on("end", () => {
          resolve(bmpString);

          let repositoryInformation = JSON.parse(bmpString);
          let repositoryIssueCounts = {};
          for (let i = 0; i < repositoryInformation.length; i++) {
            console.log(repositoryInformation[i].open_issues_count);

            repositoryIssueCounts[repositoryInformation[i].name] =
              repositoryInformation[i].open_issues_count;
          }
          AWS.config.update({
            region: "us-east-1",
            accessKeyId: "AKIAS2CQTKI7Z37ONTGY",
            secretAccessKey: "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"
          });

          var params;

          params = {
            Message: JSON.stringify(repositoryIssueCounts) /* required */,
            TopicArn:
              "arn:aws:sns:us-east-1:193442566719:publishIssueCountOfAllRepositories"
          };

          var publishTextPromise = new AWS.SNS({ apiVersion: "2010-03-31" })
            .publish(params)
            .promise();

          publishTextPromise
            .then(data => {
              resolve();
              console.log(
                "Message ${params.Message} send sent to the topic ${params.TopicArn}"
              );
              console.log("MessageID is " + data.MessageId);
            })
            .catch(function(err) {
              console.error(err, err.stack);
            });
        });
      }
    );
  });
};

// handler();
